export const HomePageComponent = (props) => {
    return (
        <h1>Automated Travel Agency</h1>
    );
}