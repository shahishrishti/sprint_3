class Driver{
   constructor (driverId, driverName, address,  contact, licenseNo, vehicleNo) {
		this.driverId = driverId;
		this.driverName = driverName;
    this.address = address;
    this.contact = contact;
		this.licenseNo = licenseNo;
    this.vehicle = {"vehicleNo": vehicleNo};

  }
	}


export default Driver;