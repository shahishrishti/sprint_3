class Route {
    constructor(source, destination, distance) {
        this.source = source;
        this.destination = destination;
        this.distance = distance;
    }
}

export default Route;